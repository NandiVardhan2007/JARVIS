import 'package:flutter/material.dart';

/// The discrete "mode" JARVIS is in. Mirrors the string states used by the
/// Python HUD (dynamic_island.py): idle / listening / thinking / speaking /
/// input. We add [alert] for error surfaces.
enum AssistantState { idle, listening, thinking, speaking, input, alert }

AssistantState assistantStateFromString(String? s) {
  switch ((s ?? 'idle').toLowerCase()) {
    case 'listening':
      return AssistantState.listening;
    case 'thinking':
      return AssistantState.thinking;
    case 'speaking':
      return AssistantState.speaking;
    case 'input':
      return AssistantState.input;
    case 'auth_locked':
    case 'auth_listening':
    case 'auth_verifying':
    case 'auth_success':
    case 'auth_failed':
    case 'auth_lockout':
      return AssistantState.input;
    case 'alert':
    case 'error':
      return AssistantState.alert;
    default:
      return AssistantState.idle;
  }
}

/// Facial expression, derived from state + the text JARVIS is saying / hearing.
/// Expanded well beyond the original 5 so the face can act.
enum Emotion {
  neutral,
  happy,
  sad,
  thinking,
  alert,
  surprised,
  angry,
  love,
  curious,
  sleepy,
  wink,
}

Emotion emotionFor(AssistantState state, String text) {
  if (state == AssistantState.alert) return Emotion.angry;
  if (state == AssistantState.thinking) return Emotion.thinking;
  final t = text.toLowerCase();
  bool has(List<String> ws) => ws.any(t.contains);

  if (has(['love', 'thank', 'sweet', 'adore', 'wonderful', 'brilliant', '❤'])) {
    return Emotion.love;
  }
  if (has(['denied', 'forbidden', 'danger', 'breach', 'security', 'attack',
      'critical', 'warning'])) {
    return Emotion.angry;
  }
  if (t.contains('!') ||
      has(['wow', 'whoa', 'amazing', 'incredible', 'unbelievable', 'really'])) {
    return Emotion.surprised;
  }
  if (has(['sorry', 'error', 'fail', 'cannot', "can't", 'unable', 'issue',
      'unfortunately', 'problem'])) {
    return Emotion.sad;
  }
  if (has(['happy', 'great', 'awesome', 'good', 'success', 'done', 'yes',
      'perfect', 'excellent', 'ready', 'sure', 'glad'])) {
    return Emotion.happy;
  }
  if (t.trimRight().endsWith('?') || has(['hmm', 'perhaps', 'maybe'])) {
    return Emotion.curious;
  }
  return Emotion.neutral;
}

/// Two-tone palette per state (primary, secondary), ported from
/// dynamic_island.py `_state_colors`, with category tint for thinking.
class StateColors {
  final Color primary;
  final Color secondary;
  const StateColors(this.primary, this.secondary);
}

StateColors colorsForState(AssistantState state, String? category) {
  switch (state) {
    case AssistantState.speaking:
      return const StateColors(Color(0xFF00D4FF), Color(0xFF823CDC));
    case AssistantState.listening:
      return const StateColors(Color(0xFF32D74B), Color(0xFF00BE8C));
    case AssistantState.thinking:
      final cat = categoryStyle(category);
      final c = cat.color;
      return StateColors(c, Color.lerp(c, Colors.black, 0.5)!);
    case AssistantState.alert:
      return const StateColors(Color(0xFFFF453A), Color(0xFF8E2A24));
    case AssistantState.input:
      return const StateColors(Color(0xFFAC8E68), Color(0xFF6E5A40));
    case AssistantState.idle:
      return const StateColors(Color(0xFF5082B4), Color(0xFF285078));
  }
}

/// Category metadata for tool/now-playing cards, ported from the Python
/// CATEGORY_STYLE table.
class CategoryStyle {
  final String icon;
  final Color color;
  final String label;
  const CategoryStyle(this.icon, this.color, this.label);
}

const Map<String, CategoryStyle> _categoryStyles = {
  'MEDIA': CategoryStyle('♫', Color(0xFFFF2D55), 'Now Playing'),
  'FINANCE': CategoryStyle('◆', Color(0xFF34C759), 'Finance'),
  'EMAIL': CategoryStyle('✉', Color(0xFF5AC8FA), 'Mail'),
  'WEB': CategoryStyle('◉', Color(0xFF007AFF), 'Web Search'),
  'SYSTEM': CategoryStyle('⚙', Color(0xFFA0A0AA), 'System'),
  'FILES': CategoryStyle('▤', Color(0xFF007AFF), 'Files'),
  'CALENDAR': CategoryStyle('▦', Color(0xFFFF3B30), 'Calendar'),
  'AI': CategoryStyle('✦', Color(0xFFAF52DE), 'AI Engine'),
  'AI-GEN': CategoryStyle('✧', Color(0xFFBF5AF2), 'AI Generate'),
  'MESSAGING': CategoryStyle('◈', Color(0xFF32D74B), 'Message'),
  'CODE': CategoryStyle('❮❯', Color(0xFF5E5CE6), 'Code'),
  'RESEARCH': CategoryStyle('◇', Color(0xFFFFD60A), 'Research'),
  'MEMORY': CategoryStyle('◐', Color(0xFF64D2FF), 'Memory'),
  'TASKS': CategoryStyle('☑', Color(0xFF30D158), 'Tasks'),
  'TERMINAL': CategoryStyle('❯', Color(0xFF8E8E93), 'Terminal'),
  'GITHUB': CategoryStyle('⊛', Color(0xFFC8C8C8), 'GitHub'),
  'SCRAPER': CategoryStyle('⊞', Color(0xFF64D2FF), 'Web Scraper'),
  'INPUT': CategoryStyle('⌨', Color(0xFFAC8E68), 'Input'),
  'VISION': CategoryStyle('◉', Color(0xFF00D4FF), 'Vision'),
  'IOT': CategoryStyle('◈', Color(0xFFFF9F0A), 'Smart Home'),
  'MULTI': CategoryStyle('⊞', Color(0xFFAF52DE), 'Multi-Task'),
  'CONTACTS': CategoryStyle('◎', Color(0xFF5AC8FA), 'Contacts'),
  'DESKTOP': CategoryStyle('▣', Color(0xFF8E8E93), 'Desktop'),
  'TOOL': CategoryStyle('⚡', Color(0xFFFF9F0A), 'Tool'),
  'SECURITY': CategoryStyle('⊘', Color(0xFFFF453A), 'Security'),
  'KNOWLEDGE': CategoryStyle('❖', Color(0xFFFFD60A), 'Knowledge'),
  'NEWS': CategoryStyle('◫', Color(0xFF5AC8FA), 'News'),
  'WEATHER': CategoryStyle('◎', Color(0xFF00B4FF), 'Weather'),
  'PHONE': CategoryStyle('◈', Color(0xFF32D74B), 'Phone'),
  'TRANSLATE': CategoryStyle('◇', Color(0xFFFF9F0A), 'Translate'),
};

CategoryStyle categoryStyle(String? category) {
  if (category == null || category.isEmpty) {
    return const CategoryStyle('⚡', Color(0xFF00D4FF), 'Processing');
  }
  return _categoryStyles[category.toUpperCase()] ??
      const CategoryStyle('⚡', Color(0xFF00D4FF), 'Processing');
}

/// Now-playing metadata surfaced by the media tool.
class NowPlaying {
  final String title;
  final String artist;
  final String? imageUrl;
  final bool playing;

  const NowPlaying({
    required this.title,
    required this.artist,
    this.imageUrl,
    this.playing = true,
  });

  factory NowPlaying.fromJson(Map<String, dynamic> j) => NowPlaying(
        title: (j['title'] ?? '').toString(),
        artist: (j['artist'] ?? '').toString(),
        imageUrl: (j['image_url'] ?? j['imageUrl'])?.toString(),
        playing: j['playing'] == null ? true : j['playing'] == true,
      );
}

/// The full snapshot of JARVIS state that drives the whole UI. This is the
/// shape produced by [JarvisConnection] from either the live WebSocket feed
/// or the built-in demo driver.
@immutable
class JarvisSnapshot {
  final AssistantState state;

  /// 0..1 amplitude of JARVIS's own voice (drives the mouth + waveform).
  final double aiLevel;

  /// 0..1 amplitude of the user's microphone (drives the listening ring).
  final double micLevel;

  final bool micMuted;
  final String? category;
  final String toolName;
  final String description;

  /// Last thing the user said (STT transcript).
  final String transcript;

  /// Last thing JARVIS said.
  final String response;

  final NowPlaying? nowPlaying;

  /// True while the WebSocket bridge is connected. False in demo/offline.
  final bool connected;

  /// Raw state string for passing through custom states like 'auth_locked'
  final String stateString;

  const JarvisSnapshot({
    this.state = AssistantState.idle,
    this.aiLevel = 0,
    this.micLevel = 0,
    this.micMuted = false,
    this.category,
    this.toolName = '',
    this.description = '',
    this.transcript = '',
    this.response = '',
    this.nowPlaying,
    this.connected = false,
    this.stateString = 'idle',
  });

  /// The text used to pick an emotion (what's being said, or heard).
  String get emotionText =>
      state == AssistantState.speaking ? response : transcript;

  Emotion get emotion => emotionFor(state, emotionText);

  StateColors get colors => colorsForState(state, category);

  /// The single caption line shown under the face.
  String get caption {
    switch (state) {
      case AssistantState.listening:
        return transcript.isNotEmpty ? transcript : 'Listening…';
      case AssistantState.thinking:
        return description.isNotEmpty ? description : 'Thinking…';
      case AssistantState.speaking:
        return response.isNotEmpty ? response : 'Speaking…';
      case AssistantState.input:
        return 'Type a command…';
      case AssistantState.alert:
        return description.isNotEmpty ? description : 'Something went wrong';
      case AssistantState.idle:
        return connected ? 'Ready' : 'Offline · Demo mode';
    }
  }

  JarvisSnapshot copyWith({
    AssistantState? state,
    double? aiLevel,
    double? micLevel,
    bool? micMuted,
    String? category,
    String? toolName,
    String? description,
    String? transcript,
    String? response,
    NowPlaying? nowPlaying,
    bool clearNowPlaying = false,
    bool? connected,
    String? stateString,
  }) {
    return JarvisSnapshot(
      state: state ?? this.state,
      aiLevel: aiLevel ?? this.aiLevel,
      micLevel: micLevel ?? this.micLevel,
      micMuted: micMuted ?? this.micMuted,
      category: category ?? this.category,
      toolName: toolName ?? this.toolName,
      description: description ?? this.description,
      transcript: transcript ?? this.transcript,
      response: response ?? this.response,
      nowPlaying: clearNowPlaying ? null : (nowPlaying ?? this.nowPlaying),
      connected: connected ?? this.connected,
      stateString: stateString ?? this.stateString,
    );
  }

  /// Build a snapshot by merging an incoming JSON message onto the current one,
  /// so partial updates (e.g. only `ai_level`) don't wipe other fields.
  JarvisSnapshot merge(Map<String, dynamic> j) {
    double? asLevel(dynamic v) =>
        v == null ? null : (v as num).toDouble().clamp(0.0, 1.0);

    NowPlaying? np = nowPlaying;
    bool clear = false;
    if (j.containsKey('now_playing')) {
      final raw = j['now_playing'];
      if (raw == null) {
        clear = true;
      } else if (raw is Map) {
        np = NowPlaying.fromJson(Map<String, dynamic>.from(raw));
      }
    }

    return copyWith(
      stateString: j['state']?.toString(),
      state: j.containsKey('state')
          ? assistantStateFromString(j['state']?.toString())
          : null,
      aiLevel: asLevel(j['ai_level']),
      micLevel: asLevel(j['mic_level']),
      micMuted: j.containsKey('mic_muted') ? j['mic_muted'] == true : null,
      category: j['category']?.toString(),
      toolName: j['tool_name']?.toString(),
      description: j['description']?.toString(),
      transcript: j['transcript']?.toString(),
      response: (j['response'] ?? j['last_response'])?.toString(),
      nowPlaying: np,
      clearNowPlaying: clear,
      connected: j.containsKey('connected') ? j['connected'] == true : null,
    );
  }
}
