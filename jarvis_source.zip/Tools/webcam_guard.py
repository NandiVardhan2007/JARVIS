"""
Webcam Gesture Control & Live Visual Context Analyzer for JARVIS.
Uses OpenCV + MediaPipe (optional) — uses lazy imports so missing
packages never crash the main app at startup.
"""

import os
import time
import logging
import threading
import base64
import requests
from livekit.agents import function_tool

logger = logging.getLogger(__name__)

# Active session trackers
_camera_active = False
_camera_thread = None
_latest_frame = None  # Holds raw numpy array of last frame
_latest_encoded_frame = None  # Holds JPEG encoded bytes for live HTTP stream
_http_server = None

# UDP client to send commands back to JARVIS session
import socket
_sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)

def _send_action_command(action_text: str):
    """Sends a text command back to JARVIS via internal UDP port."""
    try:
        import json
        payload = json.dumps({'type': 'text_input', 'text': action_text}).encode("utf-8")
        _sock.sendto(payload, ("127.0.0.1", 5004))
        _sock.sendto(payload, ("127.0.0.1", 5016))
    except Exception:
        pass


def _get_screen_size():
    try:
        from Xlib import display
        d = display.Display()
        s = d.screen()
        return s.width_in_pixels, s.height_in_pixels
    except Exception:
        return 1920, 1080

_cached_standby_frame = None

def _get_standby_frame_bytes():
    global _cached_standby_frame
    if _cached_standby_frame is not None:
        return _cached_standby_frame
    try:
        import cv2
        import numpy as np
        img = np.zeros((480, 640, 3), dtype=np.uint8)
        cv2.rectangle(img, (15, 15), (625, 465), (50, 40, 20), 2)
        cv2.putText(img, "JARVIS VISUAL CORE - STANDBY", (100, 220), cv2.FONT_HERSHEY_SIMPLEX, 0.75, (255, 212, 0), 2)
        cv2.putText(img, "Say 'start webcam' or tap 'Start Cam' to activate", (75, 270), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (180, 180, 180), 1)
        _, buf = cv2.imencode('.jpg', img)
        _cached_standby_frame = buf.tobytes()
        return _cached_standby_frame
    except Exception:
        return b'\xff\xd8\xff\xe0\x00\x10JFIF\x00\x01\x01\x01\x00`\x00`\x00\x00\xff\xdb\x00C\x00\x08\x06\x06\x07\x06\x05\x08\x07\x07\x07\t\t\x08\n\x0c\x14\r\x0c\x0b\x0b\x0c\x19\x12\x13\x0f\x14\x1d\x1a\x1f\x1e\x1d\x1a\x1c\x1c $.\x27 ",#\x1c\x1c(7),01444\x1f\x279=82<.342\xff\xc0\x00\x0b\x08\x00\x01\x00\x01\x01\x01\x11\x00\xff\xc4\x00\x1f\x00\x00\x01\x05\x01\x01\x01\x01\x01\x01\x00\x00\x00\x00\x00\x00\x00\x00\x01\x02\x03\x04\x05\x06\x07\x08\t\n\x0b\xff\xda\x00\x08\x01\x01\x00\x00?\x00\xbf\x00\xff\xd9'

def _start_mjpeg_stream_server():
    global _http_server
    if _http_server is not None:
        return

    from http.server import HTTPServer, BaseHTTPRequestHandler
    from socketserver import ThreadingMixIn

    class ThreadedHTTPServer(ThreadingMixIn, HTTPServer):
        daemon_threads = True
        allow_reuse_address = True


    class CamHandler(BaseHTTPRequestHandler):
        def do_GET(self):
            if self.path.startswith('/snapshot') or self.path.startswith('/frame'):
                try:
                    if _camera_active and _latest_encoded_frame is not None:
                        frame_bytes = _latest_encoded_frame
                    else:
                        frame_bytes = _get_standby_frame_bytes()

                    self.send_response(200)
                    self.send_header('Content-type', 'image/jpeg')
                    self.send_header('Content-length', str(len(frame_bytes)))
                    self.send_header('Access-Control-Allow-Origin', '*')
                    self.send_header('Cache-Control', 'no-cache, no-store, must-revalidate')
                    self.end_headers()
                    self.wfile.write(frame_bytes)
                except Exception:
                    pass
                return

            if self.path.startswith('/video_feed') or self.path == '/':
                self.send_response(200)
                self.send_header('Content-type', 'multipart/x-mixed-replace; boundary=jpgboundary')
                self.send_header('Access-Control-Allow-Origin', '*')
                self.end_headers()
                while True:
                    try:
                        if _camera_active and _latest_encoded_frame is not None:
                            frame_bytes = _latest_encoded_frame
                        else:
                            frame_bytes = _get_standby_frame_bytes()

                        self.wfile.write(b'--jpgboundary\r\n')
                        self.send_header('Content-type', 'image/jpeg')
                        self.send_header('Content-length', str(len(frame_bytes)))
                        self.end_headers()
                        self.wfile.write(frame_bytes)
                        self.wfile.write(b'\r\n')
                        time.sleep(0.04)
                    except Exception:
                        break


        def log_message(self, format, *args):
            pass  # Suppress HTTP access logging in stdout

    try:
        _http_server = ThreadedHTTPServer(('0.0.0.0', 5005), CamHandler)
        t = threading.Thread(target=_http_server.serve_forever, daemon=True)
        t.start()
        logger.info("Live MJPEG video stream server running at http://127.0.0.1:5005/video_feed")
    except Exception as e:
        _http_server = True
        logger.debug(f"MJPEG server port 5005 status: {e}")



def _get_hand_tracker():
    try:
        import mediapipe as mp
        # 1. Try legacy solutions API first if present
        if hasattr(mp, 'solutions') and hasattr(mp.solutions, 'hands'):
            logger.info("MediaPipe: Using mp.solutions.hands legacy API")
            return ('legacy', mp.solutions.hands.Hands(max_num_hands=1, min_detection_confidence=0.6), mp)
        
        # 2. MediaPipe 0.10+ Tasks API
        from mediapipe.tasks import python as mp_tasks
        from mediapipe.tasks.python import vision
        
        model_path = os.path.join(os.path.dirname(os.path.dirname(__file__)), "models", "hand_landmarker.task")
        if not os.path.exists(model_path):
            os.makedirs(os.path.dirname(model_path), exist_ok=True)
            url = "https://storage.googleapis.com/mediapipe-models/hand_landmarker/hand_landmarker/float16/1/hand_landmarker.task"
            import urllib.request
            logger.info("Downloading MediaPipe hand_landmarker.task model...")
            urllib.request.urlretrieve(url, model_path)
            
        base_options = mp_tasks.BaseOptions(model_asset_path=model_path)
        options = vision.HandLandmarkerOptions(
            base_options=base_options,
            num_hands=1,
            min_hand_detection_confidence=0.5,
            min_hand_presence_confidence=0.5,
            min_tracking_confidence=0.5
        )
        landmarker = vision.HandLandmarker.create_from_options(options)
        logger.info("MediaPipe 0.10+ HandLandmarker Tasks API initialized successfully!")
        return ('tasks', landmarker, mp)
    except Exception as e:
        logger.warning(f"MediaPipe hand tracking initialization error ({e}). Gesture tracking disabled.")
        return (None, None, None)

def _find_webcam_capture(cv2):
    """Probes multiple video device indices and FOURCC formats to open an available camera."""
    for idx in [0, 1, 2, 3]:
        # 1. Try V4L2 with MJPG pixel format (required by Sonix and laptop webcams)
        try:
            cap = cv2.VideoCapture(idx, cv2.CAP_V4L2)
            if cap.isOpened():
                cap.set(cv2.CAP_PROP_FOURCC, cv2.VideoWriter_fourcc(*'MJPG'))
                cap.set(cv2.CAP_PROP_FRAME_WIDTH, 640)
                cap.set(cv2.CAP_PROP_FRAME_HEIGHT, 480)
                ret, frame = cap.read()
                if ret and frame is not None:
                    logger.info(f"Webcam opened successfully on index {idx} (V4L2 MJPG)")
                    return cap
                cap.release()
        except Exception:
            pass

        # 2. Fallback to default backend with MJPG
        try:
            cap = cv2.VideoCapture(idx)
            if cap.isOpened():
                cap.set(cv2.CAP_PROP_FOURCC, cv2.VideoWriter_fourcc(*'MJPG'))
                ret, frame = cap.read()
                if ret and frame is not None:
                    logger.info(f"Webcam opened successfully on index {idx} (MJPG)")
                    return cap
                cap.release()
        except Exception:
            pass

        # 3. Fallback to default backend standard
        try:
            cap = cv2.VideoCapture(idx)
            if cap.isOpened():
                ret, frame = cap.read()
                if ret and frame is not None:
                    logger.info(f"Webcam opened successfully on index {idx}")
                    return cap
                cap.release()
        except Exception:
            pass
    return None


def _camera_loop():
    global _camera_active, _latest_frame, _latest_encoded_frame

    try:
        import cv2
        import numpy as np
    except ImportError:
        logger.error("opencv-python not installed. Cannot start webcam.")
        return

    screen_w, screen_h = _get_screen_size()
    uinput_mouse = None
    try:
        import evdev
        from evdev import UInput, ecodes as e
        # Use EV_REL (relative movement) — GNOME Wayland treats EV_ABS as a touchscreen,
        # only EV_REL is recognised as a real pointer and actually moves the cursor.
        cap_events = {
            e.EV_REL: [e.REL_X, e.REL_Y, e.REL_WHEEL],
            e.EV_KEY: [e.BTN_LEFT, e.BTN_RIGHT, e.BTN_MIDDLE],
        }
        uinput_mouse = UInput(cap_events, name='jarvis-air-mouse')
        logger.info("Kernel /dev/uinput virtual relative mouse initialized for GNOME Wayland!")
    except Exception as _ue:
        logger.warning(f"uinput mouse unavailable: {_ue}")

    mouse = None
    try:
        from pynput.mouse import Controller, Button
        mouse = Controller()
    except Exception as e:
        logger.warning(f"pynput mouse controller unavailable ({e}). Cursor control disabled.")

    logger.info("Starting webcam monitoring loop with hand mouse control...")
    cap = _find_webcam_capture(cv2)
    if cap is None or not cap.isOpened():
        logger.error("Could not open any webcam device.")
        _camera_active = False
        if uinput_mouse:
            try: uinput_mouse.close()
            except Exception: pass
        return


    _start_mjpeg_stream_server()

    tracker_mode, tracker, mp_module = _get_hand_tracker()

    screen_w, screen_h = _get_screen_size()
    prev_x, prev_y = screen_w // 2, screen_h // 2
    alpha = 0.35  # Exponential moving average smoothing factor
    margin = 0.15  # Bounding margin to easily reach screen corners

    is_dragging = False
    pinch_start_time = 0.0
    last_click_time = 0.0

    last_action_gesture = ""
    last_action_time = 0.0
    action_cooldown = 1.0


    # Load OpenCV Face Classifier
    face_cascade = None
    try:
        cascade_path = cv2.data.haarcascades + 'haarcascade_frontalface_default.xml'
        if os.path.exists(cascade_path):
            face_cascade = cv2.CascadeClassifier(cascade_path)
    except Exception:
        pass

    while _camera_active:
        ret, frame = cap.read()
        if not ret:
            time.sleep(0.01)
            continue

        now = time.time()


        # Save raw frame before annotations
        _latest_frame = frame.copy()

        # Mirror frame for natural camera preview
        frame = cv2.flip(frame, 1)
        h, w, _ = frame.shape

        # Face Recognition / Detection
        if face_cascade is not None:
            try:
                gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
                faces = face_cascade.detectMultiScale(gray, scaleFactor=1.2, minNeighbors=5, minSize=(60, 60))
                for (fx, fy, fw, fh) in faces:
                    cv2.rectangle(frame, (fx, fy), (fx + fw, fy + fh), (0, 212, 255), 2)
                    cv2.rectangle(frame, (fx, fy - 22), (fx + fw, fy), (0, 212, 255), cv2.FILLED)
                    cv2.putText(frame, "MASTER FACE CONFIRMED", (fx + 4, fy - 6), cv2.FONT_HERSHEY_SIMPLEX, 0.45, (0, 0, 0), 2)
            except Exception:
                pass

        landmarks = None


        if tracker is not None:
            rgb_frame = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)

            if tracker_mode == 'tasks':
                mp_image = mp_module.Image(image_format=mp_module.ImageFormat.SRGB, data=rgb_frame)
                results = tracker.detect(mp_image)
                if results.hand_landmarks:
                    landmarks = results.hand_landmarks[0]
            elif tracker_mode == 'legacy':
                results = tracker.process(rgb_frame)
                if results.multi_hand_landmarks:
                    landmarks = results.multi_hand_landmarks[0].landmark

            if landmarks:
                # Landmark 8: Index Tip, Landmark 4: Thumb Tip, Landmark 0: Wrist, Landmark 9: Middle MCP
                index_x, index_y = landmarks[8].x, landmarks[8].y
                thumb_x, thumb_y = landmarks[4].x, landmarks[4].y
                wrist_x, wrist_y = landmarks[0].x, landmarks[0].y

                # Calculate hand scale (Index to Wrist distance) to adapt pinch threshold automatically
                hand_scale = np.hypot(index_x - wrist_x, index_y - wrist_y) + 1e-5

                # Normalize index tip position to screen coordinates with comfortable margin (0.12)
                norm_x = np.clip((index_x - margin) / (1.0 - 2 * margin), 0.0, 1.0)
                norm_y = np.clip((index_y - margin) / (1.0 - 2 * margin), 0.0, 1.0)

                target_x = int(norm_x * screen_w)
                target_y = int(norm_y * screen_h)

                # Smooth cursor movement using EMA with 3px anti-jitter deadzone
                dx = abs(target_x - prev_x)
                dy = abs(target_y - prev_y)
                if dx > 2 or dy > 2:
                    curr_x = int(alpha * target_x + (1 - alpha) * prev_x)
                    curr_y = int(alpha * target_y + (1 - alpha) * prev_y)
                    # Compute relative delta BEFORE updating prev (delta = new - old)
                    rel_dx = curr_x - prev_x
                    rel_dy = curr_y - prev_y
                    prev_x, prev_y = curr_x, curr_y
                else:
                    curr_x, curr_y = prev_x, prev_y
                    rel_dx, rel_dy = 0, 0

                # Move desktop cursor — send relative deltas via uinput (GNOME Wayland)
                if uinput_mouse and (rel_dx != 0 or rel_dy != 0):
                    try:
                        from evdev import ecodes as e
                        uinput_mouse.write(e.EV_REL, e.REL_X, int(rel_dx))
                        uinput_mouse.write(e.EV_REL, e.REL_Y, int(rel_dy))
                        uinput_mouse.syn()
                    except Exception:
                        pass

                if mouse:
                    try:
                        mouse.position = (curr_x, curr_y)
                    except Exception:
                        pass

                # Adaptive Pinch Distance (Index tip to Thumb tip relative to hand scale)
                pinch_raw = np.hypot(index_x - thumb_x, index_y - thumb_y)
                rel_pinch = pinch_raw / hand_scale
                now = time.time()

                # PINCH CLICK & DRAG WINDOW LOGIC
                is_pinched = (rel_pinch < 0.28) or (pinch_raw < 0.045)

                ix_px, iy_px = int(index_x * w), int(index_y * h)
                tx_px, ty_px = int(thumb_x * w), int(thumb_y * h)

                if is_pinched:
                    if not is_dragging:
                        is_dragging = True
                        pinch_start_time = now
                        if uinput_mouse:
                            try:
                                from evdev import ecodes as e
                                uinput_mouse.write(e.EV_KEY, e.BTN_LEFT, 1)
                                uinput_mouse.syn()
                            except Exception: pass
                        if mouse:
                            try:
                                from pynput.mouse import Button
                                mouse.press(Button.left)
                            except Exception: pass

                    # Draw vibrant active pinch indicator (Cyan-Green glowing line)
                    cv2.line(frame, (ix_px, iy_px), (tx_px, ty_px), (255, 212, 0), 4)
                    cv2.circle(frame, (ix_px, iy_px), 12, (255, 212, 0), cv2.FILLED)
                    cv2.putText(frame, "PINCH CLICK / GRAB ACTIVE", (20, 50), cv2.FONT_HERSHEY_SIMPLEX, 0.75, (255, 212, 0), 2)
                else:
                    if is_dragging:
                        is_dragging = False
                        pinch_duration = now - pinch_start_time
                        if uinput_mouse:
                            try:
                                from evdev import ecodes as e
                                uinput_mouse.write(e.EV_KEY, e.BTN_LEFT, 0)
                                uinput_mouse.syn()
                            except Exception: pass
                        if mouse:
                            try:
                                from pynput.mouse import Button
                                mouse.release(Button.left)
                            except Exception: pass

                        # Short tap pinch (<0.35s) = Click / Double Click
                        if pinch_duration < 0.35:
                            if (now - last_click_time) < 0.4:
                                logger.info("Double pinch detected -> Double Click")
                                if mouse:
                                    try:
                                        from pynput.mouse import Button
                                        mouse.click(Button.left, 2)
                                    except Exception: pass
                            else:
                                logger.info("Short pinch detected -> Single Click")
                                if mouse:
                                    try:
                                        from pynput.mouse import Button
                                        mouse.click(Button.left, 1)
                                    except Exception: pass

                            last_click_time = now

                    # Draw green pointer circle at index tip position
                    cv2.circle(frame, (ix_px, iy_px), 8, (0, 255, 0), cv2.FILLED)
                    cv2.putText(frame, f"INDEX CURSOR ({curr_x}, {curr_y})", (20, 50), cv2.FONT_HERSHEY_SIMPLEX, 0.7, (0, 255, 0), 2)

                # Action Gestures (Victory, Fist, Palm, Thumbs Up/Down, Point Up, Rock On)
                gesture = _analyze_gesture(landmarks)
                if gesture:
                    cv2.putText(frame, f"GESTURE: {gesture}", (20, 85), cv2.FONT_HERSHEY_SIMPLEX, 0.75, (0, 255, 255), 2)
                    if (gesture != last_action_gesture or (now - last_action_time) > action_cooldown):
                        last_action_time = now
                        last_action_gesture = gesture
                        logger.info(f"Gesture detected: {gesture}")
                        _handle_gesture_action(gesture)
            else:
                if (now - last_action_time) > 0.8:
                    last_action_gesture = ""




        # Encode frame to JPEG for HTTP video stream
        try:
            _, buffer = cv2.imencode('.jpg', frame)
            _latest_encoded_frame = buffer.tobytes()
        except Exception:
            pass

        # Show live feedback desktop window
        try:
            cv2.imshow("JARVIS Visual Core — Press 'q' to exit", frame)
            key = cv2.waitKey(1) & 0xFF
            if key == ord('q'):
                break
        except Exception:
            pass

    # Safety release when loop exits
    if mouse and is_dragging:
        try:
            from pynput.mouse import Button
            mouse.release(Button.left)
        except Exception:
            pass

    cap.release()
    cv2.destroyAllWindows()
    logger.info("Webcam monitoring stopped.")
    _latest_frame = None

def _analyze_gesture(landmarks) -> str | None:
    try:
        index_up   = landmarks[8].y  < landmarks[6].y
        middle_up  = landmarks[12].y < landmarks[10].y
        ring_up    = landmarks[16].y < landmarks[14].y
        pinky_up   = landmarks[20].y < landmarks[18].y
        thumb_up   = landmarks[4].y  < landmarks[3].y
        thumb_down = landmarks[4].y  > landmarks[2].y and landmarks[4].y > landmarks[8].y

        # FIST: all main fingers down
        if not index_up and not middle_up and not ring_up and not pinky_up and not thumb_up:
            return "FIST"

        # PALM: all 4 fingers up
        if index_up and middle_up and ring_up and pinky_up:
            return "PALM"

        # VICTORY: index & middle up, ring & pinky down
        if index_up and middle_up and not ring_up and not pinky_up:
            return "VICTORY"

        # THUMBS_UP: thumb pointing up, other 4 fingers folded
        if thumb_up and not index_up and not middle_up and not ring_up and not pinky_up:
            return "THUMBS_UP"

        # THUMBS_DOWN: thumb pointing down, other 4 fingers folded
        if thumb_down and not index_up and not middle_up and not ring_up and not pinky_up:
            return "THUMBS_DOWN"

        # POINT_UP: index up, all others down
        if index_up and not middle_up and not ring_up and not pinky_up:
            return "POINT_UP"

        # ROCK_ON: index & pinky up, middle & ring down
        if index_up and pinky_up and not middle_up and not ring_up:
            return "ROCK_ON"

    except Exception:
        pass
    return None

def _handle_gesture_action(gesture: str):
    mapping = {
        "FIST":        "pause playback",
        "PALM":        "take a screenshot",
        "VICTORY":     "get system status info",
        "THUMBS_UP":   "resume playback",
        "THUMBS_DOWN": "mute volume",
        "POINT_UP":    "increase volume by 10 percent",
        "ROCK_ON":     "scan system for viruses",
    }
    action = mapping.get(gesture)
    if action:
        logger.info(f"Gesture '{gesture}' → triggering action: {action}")
        try:
            from agent import send_hud_state
            send_hud_state({
                "state": "thinking",
                "category": "VISION",
                "tool_name": f"GESTURE_{gesture}",
                "description": f"Triggering gesture action: {action}",
            })
        except Exception:
            pass
        _send_action_command(action)



@function_tool
async def start_webcam_guard() -> str:
    """
    Activates your webcam to monitor hand gestures and live visual context.
    Also required before asking JARVIS to analyze what is in front of the camera.
    """
    global _camera_active, _camera_thread

    try:
        import cv2
    except ImportError:
        return ("OpenCV is not installed. Run:\n"
                "  pip install opencv-python mediapipe --break-system-packages")

    if _camera_active:
        return "Webcam monitoring is already active, sir."

    _camera_active = True
    _camera_thread = threading.Thread(target=_camera_loop, daemon=True)
    _camera_thread.start()

    return ("Webcam activated. I have visual contact, sir.\n"
            "  ✊ FIST → pause playback\n"
            "  ✋ PALM → take screenshot\n"
            "  ✌️ VICTORY → system status\n"
            "  👍 THUMBS UP → resume playback\n"
            "  👎 THUMBS DOWN → mute volume\n"
            "  👆 POINT UP → volume up\n"
            "  🤟 ROCK ON → virus scan")


@function_tool
async def stop_webcam_guard() -> str:
    """Deactivates the webcam monitoring session."""
    global _camera_active
    if not _camera_active:
        return "Webcam is not currently active."
    _camera_active = False
    return "Webcam tracking offline. Visual core suspended."


@function_tool
async def analyze_webcam_frame_vlm(user_question: str) -> str:
    """
    Looks through the active webcam and answers the user's question about the image
    (e.g., 'What book am I holding?', 'What am I doing right now?').

    Args:
        user_question: What you want JARVIS to look for or describe (e.g. 'Read the text on the object I am holding').
    """
    global _latest_frame

    # If camera is not active, boot it temporarily, capture, and stop it
    temp_camera = False
    try:
        import cv2
    except ImportError:
        return "Vision features require opencv-python to be installed."

    if _latest_frame is None:
        logger.info("Vision: Camera not running. Spinning up temporary frame capture...")
        cap = cv2.VideoCapture(0)
        if not cap.isOpened():
            return "Failed to open webcam for visual check."
        # Let scanner warm up
        for _ in range(5):
            ret, frame = cap.read()
        cap.release()
        if not ret:
            return "Failed to capture visual frame from webcam."
    else:
        frame = _latest_frame.copy()

    # Encode frame to base64
    try:
        _, buffer = cv2.imencode('.jpg', frame)
        base64_image = base64.b64encode(buffer).decode('utf-8')
    except Exception as e:
        return f"Failed to process image capture: {e}"

    # VLM request to local LM Studio (running LlaVA or Moondream)
    local_llm_url = os.getenv("LOCAL_LLM_URL", "http://localhost:1234/v1")
    # Clean completions endpoint to get models url
    base_url = local_llm_url.replace("/chat/completions", "")
    if not base_url.endswith("/v1"):
        base_url += "/v1"

    headers = {"Content-Type": "application/json"}
    payload = {
        "model": "local-model", # Default model alias in LM Studio
        "messages": [
            {
                "role": "user",
                "content": [
                    {"type": "text", "text": f"You are JARVIS's visual cortex. Answer this user request directly, wittily, and in a human way: {user_question}"},
                    {"type": "image_url", "image_url": {"url": f"data:image/jpeg;base64,{base64_image}"}}
                ]
            }
        ],
        "temperature": 0.4
    }

    try:
        logger.info(f"Sending image to Local VLM ({base_url}/chat/completions)...")
        resp = requests.post(f"{base_url}/chat/completions", json=payload, headers=headers, timeout=20)
        if resp.status_code == 200:
            result = resp.json()
            description = result["choices"][0]["message"]["content"]
            return description
        else:
            return f"The local vision server returned an error: Code {resp.status_code}. Make sure LM Studio is running a Vision-enabled model."
    except Exception as e:
        logger.error(f"Local VLM connection failed: {e}")
        return f"I couldn't contact my visual sub-agent at port 1234. Make sure LM Studio is active."


@function_tool
async def analyze_what_master_is_doing() -> str:
    """
    Analyzes the current webcam frame and describes the master's activity.
    Use this when the user asks something like 'what am I doing', 'what do you see'.
    """
    return await analyze_webcam_frame_vlm(
        "Look at this image and describe in 1-2 sentences what the person in front of the camera is doing right now. Be playful and precise, like JARVIS would be."
    )

# Auto-start HTTP MJPEG stream server on port 5005
try:
    _start_mjpeg_stream_server()
except Exception as _err:
    logger.warning(f"Could not auto-start MJPEG server: {_err}")



